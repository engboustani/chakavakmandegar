@extends('masterclient')

@section('content')
<div class="container">
        <div class="content">
            <login-modal></login-modal>
        </div>
</div>
@endsection