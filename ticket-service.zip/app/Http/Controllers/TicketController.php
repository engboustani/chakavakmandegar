<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class TicketController extends Controller
{
    public function getListUser(Request $request)
    {
        $userid = Auth::id();
        $tickets = \App\Ticket::where('user_id', $userid)->latest()->get();

        return $tickets->toJson();
    }
}
